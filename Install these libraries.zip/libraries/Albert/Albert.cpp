/* 
Albert.cpp 
Arduino library Albert
Version 17-12-2015
Version 29-4-2016 #if defined(__arm__)
Version 8-2-2017 Added analogReadFast code for SAMD21

This program is free software: you can redistribute it and/or modify it under the terms of the GNU General Public License
as published by the Free Software Foundation, either version 3 of the License, or (at your option) any later version.
This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty
of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.
You should have received a copy of the GNU General Public License along with this program. If not, see http://www.gnu.org/licenses.

Version 17-12-2015 analogReadfast, heartbeat
*/

#include <avr/pgmspace.h>
#include <Arduino.h>
#include "Albert.h"

// written by David A. Mellis. Based on code by Rob Faludi http://www.faludi.com
int availableRAM() 
{ int size = 70000; 
  byte *buf;
  while ((buf = (byte *) malloc(--size)) == NULL);
  free(buf);
  return size;
}

void openDrain(byte pin, bool value)
{ if(value) pinMode(pin, INPUT);
  else pinMode(pin, OUTPUT); 
  digitalWrite(pin, LOW);  
}

void blinkLed(byte pin, int n)
{ pinMode(pin, OUTPUT); 
  for(byte i=0; i<n; i++)
  { digitalWrite(pin, HIGH);       
    delay(300);                 
    digitalWrite(pin, LOW);   
    delay(300);
  }
}

void maxLoops(const unsigned long loops)
{ static unsigned long i=0;
  if(++i > loops) while(1);
}

// With a too small LED resistance we can’t see the heartbeat effect, take about 500Ohm.
void heartbeat(byte pin) 
{ pinMode(pin, OUTPUT); 
  unsigned long now = millis();
  static unsigned long last_time = 0;
  static byte hbval = 128;
  static char hbdelta = 8; // char = signed byte
 
  if ((now - last_time) < 40) return;
  last_time = now;
  if (hbval > 192) hbdelta = -hbdelta; 
  if (hbval < 32) hbdelta = -hbdelta;
  hbval += hbdelta;
  analogWrite(pin, hbval);
}

/* kan simpeler:
for (int i=0; i<256; i++)
  {
    analogWrite(BLUE_LED, i);
    delay(2);
  }
*/



